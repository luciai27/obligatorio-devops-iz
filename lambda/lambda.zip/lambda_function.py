import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def check_urls(urls):
    results = {}
    for url in urls:
        try:
            response = requests.get(url, timeout=5, verify=False)
            if response.status_code == 200:
                results[url] = "OK"
            else:
                results[url] = f"Status {response.status_code}"
        except requests.exceptions.RequestException as e:
            results[url] = f"Error: {str(e)}"
    return results

# Este es el punto de entrada para AWS Lambda
def lambda_handler(event, context):
    urls = event.get("urls", [])
    if not urls:
        return {"error": "No URLs provided"}
    return check_urls(urls)
